//
//  LoginViewController.swift
//  1-Days
//
//  Created by HAKAN ÖZER on 26.02.2024.
//

import UIKit

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBAction func fncLogin(_ sender: UIButton) {
        let email = txtEmail.text
        let password = txtPassword.text
        print(email!, password!)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad call")
        
        // one line comment
        /*
         multiline comment
         */
        // let, var
        let name = "Erkan"
        // name = ""
        var surname = "Bilmem"
        surname = "Bilirim"
        
        let age = 30
        let num1 = 10.5
        let num2:Float = 10.5
        let num3:Int64 = 100
        
        let num4: Int? = 50
        if ( num4 != nil ) {
            print("Number: \(num4!)")
        }
     
        // if optional
        if let city:String? = "İzmit" {
            print(city!)
        }
        
        // Arrays
        var arr = ["İstanbul"]
        var arr1:[String] = []
        
        // add Element
        arr.append("Ankara")
        arr.append("İzmir")
        arr.append("Bursa")
        arr.append("Antalya")
        arr.append("Konya")
        
        // Get Element
        print(arr[0])
        
        // Remove
        arr.remove(at: 2)
        print(arr)
        print(arr.count)
        
        // for loop
        for item in arr {
            print(item)
        }
        print("==================")
        for i in 2...arr.count - 1 {
            print(arr[i])
        }
        print("==================")
        for i in 0...10 {
            print("i: \(i)")
        }
        print("==================")
        
        // Any
        var arr3:[Any] = []
        arr3.append("Ali")
        arr3.append(100)
        arr3.append(true)
        arr3.append(txtEmail!)
        for item in arr3 {
            
            if (item is String) {
                let stItem = item as! String
            }
            
            if (item is UITextField) {
                let txtEmail = item as! UITextField
                txtEmail.text = "ali@mail.com"
            }
            
        }
        
        // OOP
        var users: [User] = []
        let u1 = User()
        u1.name = "Erkan"
        u1.surname = "Bilmem"
        u1.email = "erkan@mail.com"
        users.append(u1)

        let u2 = User()
        u2.name = "Serkan"
        u2.surname = "Bilsin"
        u2.email = "serkan@mail.com"
        users.append(u2)
        
        for item in users {
            print(item.name)
        }
        
        let c1 = Category(cid: 10, name: "Elektornik")
        let p1 = Product(pid: 1, title: "TV", status: true, category: c1)
        let p2 = Product(pid: 2, title: "iPhone", status: true, category: c1)
        var arr4: [Product] = []
        arr4.append(p1)
        arr4.append(p2)
        print(arr4)
        
        let util = Util(data: "New Data")
        Util().baseURL
        util.noParams()
        print(Util.count)
        
        util.noReturn(name: "Mehmet", email: "mehmet@mail.com", age: 25)
        
        let sm = util.sum(name: "İstambul", count: 100)
        print("Sum: \(sm)")
        
        let params = util.params(name: "Ahmet", surname: "Bil")
        print(params.count)
        print(params.surname)
        
        
        
    }

}
