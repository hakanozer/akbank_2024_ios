//
//  RegisterViewController.swift
//  1-Days
//
//  Created by HAKAN ÖZER on 26.02.2024.
//

import UIKit

class RegisterViewController: UIViewController {
    
    
    @IBAction func fncBack(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    


}
