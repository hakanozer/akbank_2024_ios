//
//  Util.swift
//  1-Days
//
//  Created by HAKAN ÖZER on 26.02.2024.
//

import Foundation

class Util {
    
    let baseURL = "https://dummyjson.com/"
    static let count = 10
    var data:String = ""
    
    init() {
        
    }
    

    init(data: String) {
        self.data = data
    }
    
    
    // no params no return
    func noParams() {
        print("noParams Call: \(self.data)")
    }
    
    
    func noReturn(name: String, email: String, age: Int) {
        let count = name.count + email.count + age
        print("Total Count: \(count)")
    }
    
    func sum(name: String, count: Int) -> Int {
        return name.count + count
    }
    
    func params(name: String, surname: String) -> (count: Int, surname: String) {
        return (name.count, "Surname: \(surname)")
    }
    
}
