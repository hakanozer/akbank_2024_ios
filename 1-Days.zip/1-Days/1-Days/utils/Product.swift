//
//  Product.swift
//  1-Days
//
//  Created by HAKAN ÖZER on 26.02.2024.
//

import Foundation

struct Product {
    let pid: Int
    let title: String
    let status: Bool
    let category: Category
}

struct Category {
    let cid: Int
    let name: String
}
