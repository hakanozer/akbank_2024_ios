//
//  User.swift
//  1-Days
//
//  Created by HAKAN ÖZER on 26.02.2024.
//

import Foundation

class User {
    
    var name = ""
    var surname = ""
    var email = ""
    
}
