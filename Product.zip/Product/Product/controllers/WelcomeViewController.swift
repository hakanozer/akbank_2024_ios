//
//  WelcomeViewController.swift
//  Product
//
//  Created by HAKAN ÖZER on 28.02.2024.
//

import UIKit

class WelcomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { Timer in
            self.control()
        }
    }
    
    
    func control() {
        self.performSegue(withIdentifier: "login", sender: nil)
    }
    
    
    override var prefersStatusBarHidden: Bool {
        return true
    }


}
