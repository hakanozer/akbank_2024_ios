//
//  SettingsViewController.swift
//  Product
//
//  Created by HAKAN ÖZER on 29.02.2024.
//

import UIKit
import TextFieldEffects
import UserNotifications

class SettingsViewController: UIViewController {
    
    @IBOutlet weak var txtTitle: HoshiTextField!
    @IBOutlet weak var txtSubTitle: HoshiTextField!
    @IBOutlet weak var txtDetail: HoshiTextField!
    
    let center = UNUserNotificationCenter.current()
    @IBAction func fncNotification(_ sender: UIButton) {
        
        let title = txtTitle.text!
        let subTitle = txtSubTitle.text!
        let body = txtDetail.text!
        
        // Content
        let content = UNMutableNotificationContent()
        content.title = title
        content.subtitle = subTitle
        content.body = body
        content.sound = UNNotificationSound.default
        content.userInfo = ["product": "100"] as [String : Any]
        
        // Trigger
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 15, repeats: false)
        
        // Identifier
        let identifier = "identifierX"
        
        // Request
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        center.setBadgeCount(1)
        center.add(request) { (error) in
            if error != nil {
                print("Notificcation Error!")
            }else {
                print("Notificcation Start")
            }
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

}
