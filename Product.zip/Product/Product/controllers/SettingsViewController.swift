//
//  SettingsViewController.swift
//  Product
//
//  Created by HAKAN ÖZER on 29.02.2024.
//

import UIKit
import TextFieldEffects

class SettingsViewController: UIViewController {
    
    @IBOutlet weak var txtTitle: HoshiTextField!
    @IBOutlet weak var txtSubTitle: HoshiTextField!
    @IBOutlet weak var txtDetail: HoshiTextField!
    @IBAction func fncNotification(_ sender: UIButton) {
        
        let title = txtTitle.text!
        let subTitle = txtSubTitle.text!
        let body = txtDetail.text!
        print(title, subTitle, body)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

}
