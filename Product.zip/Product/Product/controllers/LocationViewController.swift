//
//  LocationViewController.swift
//  Product
//
//  Created by HAKAN ÖZER on 1.03.2024.
//

import UIKit
import MapKit

class LocationViewController: UIViewController, MKMapViewDelegate {
    
    
    @IBOutlet weak var mapView: MKMapView!
    let arr:[Dictionary<String, Any>] = [
        ["title": "İşletme-1", "detail": "İşletme-1 Detail", "lat": 41.0091956, "long": 28.9598693],
        ["title": "İşletme-2", "detail": "İşletme-2 Detail", "lat": 41.0081593, "long": 28.9666499],
        ["title": "İşletme-3", "detail": "İşletme-3 Detail", "lat": 41.0056332, "long": 28.9655341]
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.mapView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        parseLocation()
    }
    
    func parseLocation() {
        for item in arr {
            let pin = MKPointAnnotation()
            pin.coordinate.latitude = item["lat"] as! CLLocationDegrees
            pin.coordinate.longitude = item["long"] as! CLLocationDegrees
            self.mapView.addAnnotation(pin)
        }
    }

}
