//
//  AppTabBarController.swift
//  2-Days
//
//  Created by HAKAN ÖZER on 27.02.2024.
//

import UIKit

class AppTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewControllers?[0].tabBarItem.badgeValue = "3"
        selectedIndex = 1
        print("AppTabBarController Call")
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
