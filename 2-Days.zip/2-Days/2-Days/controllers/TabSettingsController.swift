//
//  TabSettingsController.swift
//  2-Days
//
//  Created by HAKAN ÖZER on 27.02.2024.
//

import UIKit

class TabSettingsController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        print("TabSettingsController Call")
    }
    


}
